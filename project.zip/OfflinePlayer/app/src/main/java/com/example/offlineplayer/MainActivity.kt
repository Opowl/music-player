@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.offlineplayer

import android.Manifest
import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class Song(val uri: String, val title: String)
data class Playlist(val id: String, val name: String, val uris: List<String>)

class PlayerVM(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()
    private val file = File(app.filesDir, "data.json")
    private val prefs = app.getSharedPreferences("p", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())

    val library = mutableStateListOf<Song>()
    val playlists = mutableStateListOf<Playlist>()
    val queue = mutableStateListOf<String>()
    var theme by mutableIntStateOf(prefs.getInt("theme", 0))
    var controller: MediaController? = null
    var isPlaying by mutableStateOf(false)
    var title by mutableStateOf<String?>(null)
    var index by mutableIntStateOf(0)
    var shuffle by mutableStateOf(false)
    var repeatAll by mutableStateOf(false)
    var timerOn by mutableStateOf(false)

    init { load(); connect() }

    // ---------- storage ----------
    private fun load() {
        try {
            if (!file.exists()) return
            val o = JSONObject(file.readText())
            val l = o.getJSONArray("library")
            for (i in 0 until l.length()) {
                val s = l.getJSONObject(i)
                library.add(Song(s.getString("u"), s.getString("t")))
            }
            val p = o.getJSONArray("playlists")
            for (i in 0 until p.length()) {
                val x = p.getJSONObject(i)
                val a = x.getJSONArray("s")
                playlists.add(Playlist(x.getString("id"), x.getString("n"), List(a.length()) { a.getString(it) }))
            }
        } catch (e: Exception) { }
    }

    private fun save() {
        try {
            val l = JSONArray()
            library.forEach { l.put(JSONObject().put("u", it.uri).put("t", it.title)) }
            val p = JSONArray()
            playlists.forEach { p.put(JSONObject().put("id", it.id).put("n", it.name).put("s", JSONArray(it.uris))) }
            file.writeText(JSONObject().put("library", l).put("playlists", p).toString())
        } catch (e: Exception) { }
    }

    // ---------- library ----------
    fun importSongs(uris: List<Uri>) {
        for (u in uris) {
            try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
            val s = u.toString()
            if (library.any { it.uri == s }) continue
            var name = "Unknown"
            try {
                ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (i >= 0) name = c.getString(i)
                    }
                }
            } catch (e: Exception) { }
            library.add(Song(s, name.substringBeforeLast('.')))
        }
        save()
    }

    fun song(uri: String): Song? = library.firstOrNull { it.uri == uri }

    fun removeFromLibrary(s: Song) {
        library.remove(s)
        for (i in playlists.indices) playlists[i] = playlists[i].copy(uris = playlists[i].uris - s.uri)
        save()
    }

    fun renameSong(uri: String, name: String) {
        val n = name.trim()
        val i = library.indexOfFirst { it.uri == uri }
        if (n.isEmpty() || i < 0) return
        library[i] = library[i].copy(title = n)
        save()
        val c = controller ?: return
        for (k in 0 until c.mediaItemCount) {
            if (k != c.currentMediaItemIndex && c.getMediaItemAt(k).mediaId == uri) c.replaceMediaItem(k, item(library[i]))
        }
    }

    fun clearLibrary() {
        controller?.clearMediaItems()
        library.clear()
        for (i in playlists.indices) playlists[i] = playlists[i].copy(uris = emptyList())
        save()
    }

    // ---------- playlists ----------
    private fun update(id: String, f: (Playlist) -> Playlist) {
        val i = playlists.indexOfFirst { it.id == id }
        if (i >= 0) { playlists[i] = f(playlists[i]); save() }
    }

    fun createPlaylist(name: String) {
        playlists.add(Playlist(UUID.randomUUID().toString(), name.trim().ifEmpty { "New playlist" }, emptyList()))
        save()
    }

    fun renamePlaylist(id: String, name: String) = update(id) { p -> p.copy(name = name.trim().ifEmpty { p.name }) }

    fun deletePlaylist(id: String) { playlists.removeAll { it.id == id }; save() }

    fun toggleInPlaylist(id: String, uri: String) = update(id) { p ->
        if (uri in p.uris) p.copy(uris = p.uris - uri) else p.copy(uris = p.uris + uri)
    }

    // ---------- playback ----------
    private fun item(s: Song) = MediaItem.Builder()
        .setMediaId(s.uri)
        .setUri(s.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).build())
        .build()

    fun play(songs: List<Song>, start: Int = 0, shuffleOn: Boolean = false) {
        val c = controller ?: return
        if (songs.isEmpty()) return
        c.shuffleModeEnabled = shuffleOn
        c.setMediaItems(songs.map { item(it) }, start, 0L)
        c.prepare()
        c.play()
    }

    fun playNext(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(listOf(s)) else c.addMediaItem(c.currentMediaItemIndex + 1, item(s))
    }

    fun addToQueue(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(listOf(s)) else c.addMediaItem(item(s))
    }

    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun sleepTimer(min: Int) {
        handler.removeCallbacksAndMessages(null)
        timerOn = min > 0
        if (min > 0) handler.postDelayed({ controller?.pause(); timerOn = false }, min * 60_000L)
    }

    fun setThemeMode(i: Int) { theme = i; prefs.edit().putInt("theme", i).apply() }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { sync(player) }
    }

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        title = p.currentMediaItem?.mediaMetadata?.title?.toString()
        index = p.currentMediaItemIndex
        shuffle = p.shuffleModeEnabled
        repeatAll = p.repeatMode == Player.REPEAT_MODE_ALL
        queue.clear()
        for (i in 0 until p.mediaItemCount) queue.add(p.getMediaItemAt(i).mediaMetadata.title?.toString() ?: "")
    }

    private fun connect() {
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val f = MediaController.Builder(ctx, token).buildAsync()
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                sync(c)
            } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(ctx))
    }

    override fun onCleared() { controller?.release(); super.onCleared() }
}

class MainActivity : ComponentActivity() {
    private val vm: PlayerVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { AppTheme(vm.theme) { Root(vm) } }
    }
}

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> true; 2 -> false; else -> isSystemInDarkTheme() }
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF1DB954), onPrimary = Color.Black,
        background = Color(0xFF121212), surface = Color(0xFF121212),
        surfaceVariant = Color(0xFF282828), onSurface = Color.White, onBackground = Color.White,
        onSurfaceVariant = Color(0xFFB3B3B3)
    ) else lightColorScheme(primary = Color(0xFF1DB954), onPrimary = Color.Black)
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Root(vm: PlayerVM) {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }
    var full by remember { mutableStateOf(false) }
    if (full) {
        BackHandler { full = false }
        NowPlaying(vm) { full = false }
    } else {
        if (open != null) BackHandler { open = null }
        Scaffold(bottomBar = {
            Column {
                if (vm.title != null) MiniPlayer(vm) { full = true }
                NavigationBar {
                    listOf(
                        "Playlists" to Icons.Filled.LibraryMusic,
                        "Add songs" to Icons.Filled.Add,
                        "Settings" to Icons.Filled.Settings
                    ).forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i; open = null },
                            icon = { Icon(icon, label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad)) {
                val o = open
                when {
                    tab == 1 -> AddSongs(vm)
                    tab == 2 -> SettingsScreen(vm)
                    o != null -> PlaylistDetail(vm, o) { open = null }
                    else -> PlaylistsScreen(vm) { open = it }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: PlayerVM, onOpen: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth().clickable { onOpen() }) {
        Row(Modifier.padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(vm.title ?: "", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            IconButton({ vm.controller?.seekToPrevious() }) { Icon(Icons.Filled.SkipPrevious, "Previous") }
            IconButton({ vm.toggle() }) {
                Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play or pause")
            }
            IconButton({ vm.controller?.seekToNext() }) { Icon(Icons.Filled.SkipNext, "Next") }
        }
    }
}

@Composable
fun MenuItem(text: String, onClick: () -> Unit) = DropdownMenuItem(text = { Text(text) }, onClick = onClick)

@Composable
fun SongRow(title: String, onClick: () -> Unit, menu: @Composable (() -> Unit) -> Unit) {
    var show by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Box {
            IconButton({ show = true }) { Icon(Icons.Filled.MoreVert, "More") }
            DropdownMenu(show, { show = false }) { menu { show = false } }
        }
    }
}

@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(t, { t = it }, singleLine = true, placeholder = { Text("Name") }) },
        confirmButton = { TextButton({ onOk(t) }) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun PlaylistsScreen(vm: PlayerVM, onOpen: (String) -> Unit) {
    var creating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Your Playlists", fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            FilledTonalButton({ creating = true }) { Text("New playlist") }
        }
        if (vm.playlists.isEmpty()) Text("No playlists yet. Tap New playlist to make one.", Modifier.padding(16.dp))
        LazyColumn {
            items(vm.playlists, key = { it.id }) { p ->
                Column(Modifier.fillMaxWidth().clickable { onOpen(p.id) }.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(p.name, fontSize = 18.sp)
                    Text("${p.uris.size} songs", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
    if (creating) NameDialog("New playlist", "", { creating = false }) { vm.createPlaylist(it); creating = false }
}

@Composable
fun PlaylistDetail(vm: PlayerVM, id: String, onBack: () -> Unit) {
    var adding by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var renameSong by remember { mutableStateOf<Song?>(null) }
    val pl = vm.playlists.firstOrNull { it.id == id } ?: return
    val songs = pl.uris.mapNotNull { vm.song(it) }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
            Text(pl.name, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            IconButton({ renaming = true }) { Icon(Icons.Filled.Edit, "Rename") }
            IconButton({ deleting = true }) { Icon(Icons.Filled.Delete, "Delete playlist") }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.play(songs) }, enabled = songs.isNotEmpty()) { Text("Play") }
            OutlinedButton({ vm.play(songs, songs.indices.random(), true) }, enabled = songs.isNotEmpty()) { Text("Shuffle") }
            OutlinedButton({ adding = true }) { Text("Add songs") }
        }
        LazyColumn {
            itemsIndexed(songs) { i, s ->
                SongRow(s.title, { vm.play(songs, i) }) { dismiss ->
                    MenuItem("Play next") { vm.playNext(s); dismiss() }
                    MenuItem("Add to queue") { vm.addToQueue(s); dismiss() }
                    MenuItem("Rename song") { renameSong = s; dismiss() }
                    MenuItem("Remove from playlist") { vm.toggleInPlaylist(id, s.uri); dismiss() }
                }
            }
        }
    }
    if (adding) AlertDialog(
        onDismissRequest = { adding = false },
        title = { Text("Add to ${pl.name}") },
        text = {
            if (vm.library.isEmpty()) Text("Your library is empty. Use the Add songs tab first.")
            else LazyColumn {
                items(vm.library, key = { it.uri }) { s ->
                    Row(Modifier.fillMaxWidth().clickable { vm.toggleInPlaylist(id, s.uri) }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(s.uri in pl.uris, { vm.toggleInPlaylist(id, s.uri) })
                        Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        confirmButton = { TextButton({ adding = false }) { Text("Done") } }
    )
    renameSong?.let { s ->
        NameDialog("Rename song", s.title, { renameSong = null }) { vm.renameSong(s.uri, it); renameSong = null }
    }
    if (renaming) NameDialog("Rename playlist", pl.name, { renaming = false }) { vm.renamePlaylist(id, it); renaming = false }
    if (deleting) AlertDialog(
        onDismissRequest = { deleting = false },
        title = { Text("Delete \"${pl.name}\"?") },
        text = { Text("Your songs stay in the library.") },
        confirmButton = { TextButton({ deleting = false; vm.deletePlaylist(id); onBack() }) { Text("Delete") } },
        dismissButton = { TextButton({ deleting = false }) { Text("Cancel") } }
    )
}

@Composable
fun AddSongs(vm: PlayerVM) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importSongs(it) }
    var target by remember { mutableStateOf<Song?>(null) }
    var renameSong by remember { mutableStateOf<Song?>(null) }
    Column(Modifier.fillMaxSize()) {
        Text("Add songs", Modifier.padding(16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Button({ picker.launch(arrayOf("audio/*")) }, Modifier.padding(horizontal = 16.dp).fillMaxWidth()) { Text("Select audio files") }
        Text("${vm.library.size} songs in library", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn {
            itemsIndexed(vm.library) { i, s ->
                SongRow(s.title, { vm.play(vm.library.toList(), i) }) { dismiss ->
                    MenuItem("Rename song") { renameSong = s; dismiss() }
                    MenuItem("Add to playlist") { target = s; dismiss() }
                    MenuItem("Play next") { vm.playNext(s); dismiss() }
                    MenuItem("Add to queue") { vm.addToQueue(s); dismiss() }
                    MenuItem("Remove from library") { vm.removeFromLibrary(s); dismiss() }
                }
            }
        }
    }
    renameSong?.let { s ->
        NameDialog("Rename song", s.title, { renameSong = null }) { vm.renameSong(s.uri, it); renameSong = null }
    }
    target?.let { s ->
        AlertDialog(
            onDismissRequest = { target = null },
            title = { Text("Add to playlist") },
            text = {
                if (vm.playlists.isEmpty()) Text("Create a playlist first.")
                else LazyColumn {
                    items(vm.playlists, key = { it.id }) { p ->
                        Row(Modifier.fillMaxWidth().clickable { vm.toggleInPlaylist(p.id, s.uri) }, verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(s.uri in p.uris, { vm.toggleInPlaylist(p.id, s.uri) })
                            Text(p.name)
                        }
                    }
                }
            },
            confirmButton = { TextButton({ target = null }) { Text("Done") } }
        )
    }
}

@Composable
fun SettingsScreen(vm: PlayerVM) {
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Theme")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("System", "Dark", "Light").forEachIndexed { i, n ->
                FilterChip(vm.theme == i, { vm.setThemeMode(i) }, { Text(n) })
            }
        }
        Text("Sleep timer" + if (vm.timerOn) " (active)" else "")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(15, 30, 60).forEach { m -> FilterChip(false, { vm.sleepTimer(m) }, { Text("$m min") }) }
            FilterChip(false, { vm.sleepTimer(0) }, { Text("Off") })
        }
        Button({ confirm = true }) { Text("Clear library") }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Clear library?") },
        text = { Text("This removes all songs from the app and your playlists. Your files are not deleted.") },
        confirmButton = { TextButton({ vm.clearLibrary(); confirm = false }) { Text("Clear") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } }
    )
}

@Composable
fun NowPlaying(vm: PlayerVM, onClose: () -> Unit) {
    val top = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(top, MaterialTheme.colorScheme.background)))) {
            NowPlayingContent(vm, onClose)
        }
    }
}

@Composable
fun NowPlayingContent(vm: PlayerVM, onClose: () -> Unit) {
    val c = vm.controller
    var pos by remember { mutableFloatStateOf(0f) }
    var dur by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(c) {
        while (true) {
            if (c != null && !dragging) {
                pos = c.currentPosition.toFloat()
                dur = maxOf(c.duration.toFloat(), 1f)
            }
            delay(500)
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        IconButton(onClose) { Icon(Icons.Filled.KeyboardArrowDown, "Close") }
        Text(vm.title ?: "Nothing playing", Modifier.padding(vertical = 16.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Slider(
            value = pos.coerceIn(0f, dur),
            onValueChange = { dragging = true; pos = it },
            valueRange = 0f..dur,
            onValueChangeFinished = { c?.seekTo(pos.toLong()); dragging = false }
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ c?.shuffleModeEnabled = !vm.shuffle }) {
                Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (vm.shuffle) MaterialTheme.colorScheme.primary else LocalContentColor.current)
            }
            IconButton({ c?.seekToPrevious() }) { Icon(Icons.Filled.SkipPrevious, "Previous") }
            IconButton({ vm.toggle() }, Modifier.size(64.dp)) {
                Icon(if (vm.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play or pause", Modifier.size(48.dp))
            }
            IconButton({ c?.seekToNext() }) { Icon(Icons.Filled.SkipNext, "Next") }
            IconButton({ c?.repeatMode = if (vm.repeatAll) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL }) {
                Icon(Icons.Filled.Repeat, "Repeat", tint = if (vm.repeatAll) MaterialTheme.colorScheme.primary else LocalContentColor.current)
            }
        }
        Text("Queue", Modifier.padding(top = 16.dp, bottom = 4.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        LazyColumn {
            itemsIndexed(vm.queue) { i, t ->
                Row(
                    Modifier.fillMaxWidth().clickable { c?.seekToDefaultPosition(i); c?.play() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        t, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (i == vm.index) MaterialTheme.colorScheme.primary else LocalContentColor.current
                    )
                    IconButton({ vm.removeFromQueue(i) }) { Icon(Icons.Filled.Close, "Remove from queue") }
                }
            }
        }
    }
}
